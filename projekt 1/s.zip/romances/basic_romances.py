class BasicRomances:
    def __init__(self, participants):
        self.participants = participants

    def start_romance(self):
        print(f"A romantic story begins between {self.participants[0]} and {self.participants[1]}.")
