class BasicEvents:
    def __init__(self):
        self.description = "This is a basic event."
    
    def start_event(self):
        print(f"Event starting: {self.description}")
